import smtplib

gmail_user = 'jan.blahuta@gmail.com'  
gmail_password = 'xwcjmzxiygewcohs'

try:  
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.ehlo()
    server.login(gmail_user, gmail_password)
except:  
    print 'Something went wrong...'
