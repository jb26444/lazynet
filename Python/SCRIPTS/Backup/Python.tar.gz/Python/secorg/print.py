#!/usr/bin/python

import paramiko
import time
import getpass
import os
import sys
from host_seedfile import network_devices
from host_config_file import host_conf


def commands():
  print '\n'.join(host_conf)




if __name__ == '__main__':
 commands()




