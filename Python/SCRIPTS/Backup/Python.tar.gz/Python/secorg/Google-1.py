def he():
    print "hello"

import sys

if __name__ == '__main__':
 he()

