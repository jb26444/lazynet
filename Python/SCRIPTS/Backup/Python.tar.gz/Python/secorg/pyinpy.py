#!/usr/bin/python
import os

def py():
  os.system('python print.py')

if __name__ == '__main__':
  py()
