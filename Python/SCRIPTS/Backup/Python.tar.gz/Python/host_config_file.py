#
#
# add your configurations in a list format
#
host_conf = ['sh processes cpu | exclude 0.00', 'sh memory summary | exclude 00000']
