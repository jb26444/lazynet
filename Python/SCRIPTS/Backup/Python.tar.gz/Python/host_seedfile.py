#
#
# Add the host addresses you want to log into
#
#network_devices = ['x.x.x.1', 'x.x.x.2', 'x.x.x.3', 'x.x.x.4']
#
network_devices = ['172.37.1.10', '172.37.1.15']
